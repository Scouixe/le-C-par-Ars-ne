﻿using System;                            // On importe les bibliothèques de base
using System.IO;                         // Pour lire et écrire dans des fichiers

class JournalSecret
{
    const string fichierMotDePasse = "motDePasse.txt";    // Nom du fichier où on stocke le mot de passe
    const string fichierJournal = "journal.txt";  // Nom du fichier où on stocke les notes

    static void Main()
    {
        // Si le fichier contenant le mot de passe n'existe pas, on demande à l'utilisateur de le créer
        if (!File.Exists(fichierMotDePasse))
        {
            CreerMotDePasse();
        }

        string motDePasse = File.ReadAllText(fichierMotDePasse);  // Lire le mot de passe depuis le fichier

        // Demander à l'utilisateur de saisir le mot de passe à chaque fois qu'il veut accéder au journal
        Console.WriteLine("=== JOURNAL SECRET ===");
        Console.Write("Entrez le mot de passe : ");
        string saisie = Console.ReadLine();       // Lecture du mot de passe saisi par l'utilisateur

        if (saisie != motDePasse)                 // Si le mot de passe est incorrect
        {
            Console.WriteLine("Mot de passe incorrect. Accès refusé.");
            return;                               // Le programme s'arrête immédiatement
        }

        while (true)                              // Boucle infinie pour le menu principal
        {
            Console.Clear();                      // Nettoyage de la console
            Console.WriteLine("=== MENU DU JOURNAL ===");
            Console.WriteLine("[1] Lire les notes");
            Console.WriteLine("[2] Ajouter une note");
            Console.WriteLine("[3] Quitter");
            Console.Write("\nVotre choix : ");
            string choix = Console.ReadLine();    // Lecture du choix utilisateur

            if (choix == "1")                     // Si l'utilisateur veut lire les notes
            {
                LireNotes();                      // Appel de la fonction LireNotes
            }
            else if (choix == "2")                // Si l'utilisateur veut ajouter une note
            {
                AjouterNote();                    // Appel de la fonction AjouterNote
            }
            else if (choix == "3")                // Si l'utilisateur veut quitter
            {
                break;                            // On sort de la boucle principale
            }
            else
            {
                Console.WriteLine("Choix invalide.");  // Si la saisie est incorrecte
            }

            Console.WriteLine("\nAppuyez sur une touche pour continuer...");
            Console.ReadKey();                    // Attente d'une touche avant de continuer
        }
    }

    // Fonction pour créer un mot de passe
    static void CreerMotDePasse()
    {
        Console.WriteLine("=== CRÉATION DU MOT DE PASSE ===");
        Console.Write("Entrez un mot de passe pour protéger votre journal : ");
        string motDePasse = Console.ReadLine();   // Lecture du mot de passe choisi par l'utilisateur
        File.WriteAllText(fichierMotDePasse, motDePasse); // On sauvegarde ce mot de passe dans un fichier
        Console.WriteLine("Mot de passe créé avec succès !");  // Confirmation à l'utilisateur
    }

    static void LireNotes()
    {
        Console.WriteLine("\n=== VOS NOTES ===");
        if (File.Exists(fichierJournal))                        // Vérifie si le fichier existe
        {
            string contenu = File.ReadAllText(fichierJournal); // Lit le contenu complet
            Console.WriteLine(contenu);                         // Affiche le contenu à l'écran
        }
        else
        {
            Console.WriteLine("Aucune note encore enregistrée."); // Message si fichier vide
        }
    }

    static void AjouterNote()
    {
        Console.Write("\nÉcrivez votre note : ");
        string note = Console.ReadLine();                       // L'utilisateur écrit sa note
        string noteAvecDate = DateTime.Now + " : " + note;      // On ajoute la date et l'heure
        File.AppendAllText(fichierJournal, noteAvecDate + "\n");// On écrit la note dans le fichier
        Console.WriteLine("Note ajoutée avec succès !");        // Confirmation à l'utilisateur
    }
}
