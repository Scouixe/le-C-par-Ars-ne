﻿using System;                           // On importe les fonctions de base du système
using System.Threading;                 // Pour faire des pauses (Thread.Sleep)

class Chronometre
{
    static void Main()
    {
        DateTime startTime = DateTime.MinValue;     // Variable pour stocker l'heure de début
        TimeSpan elapsed = TimeSpan.Zero;           // Variable pour stocker le temps écoulé
        bool enCours = false;                       // Indique si le chrono est en train de tourner

        while (true)                                // Boucle infinie pour le menu principal
        {
            Console.Clear();                        // On nettoie la console à chaque boucle
            Console.WriteLine("=== CHRONOMÈTRE ===");
            Console.WriteLine("Temps écoulé : " + elapsed);   // Affiche le temps écoulé
            Console.WriteLine();
            Console.WriteLine("[1] Démarrer");
            Console.WriteLine("[2] Arrêter");
            Console.WriteLine("[3] Réinitialiser");
            Console.WriteLine("[4] Quitter");
            Console.Write("\nVotre choix : ");

            string choix = Console.ReadLine();      // Lecture du choix de l'utilisateur

            if (choix == "1" && !enCours)           // Si l'utilisateur choisit "1" et que le chrono est à l'arrêt
            {
                startTime = DateTime.Now;           // On enregistre le temps de départ
                enCours = true;                     // On indique que le chrono a commencé
                while (enCours)                     // Boucle qui affiche le temps en direct
                {
                    Console.Clear();
                    elapsed = DateTime.Now - startTime;                                         // Calcule le temps depuis le début
                    Console.WriteLine("=== CHRONOMÈTRE EN COURS ===");
                    Console.WriteLine("Temps : " + elapsed.ToString(@"hh\:mm\:ss\.fff"));     // Affichage formaté
                    Console.WriteLine("\nAppuyez sur 'S' pour stopper");
                    Thread.Sleep(1000);                                                      // Pause d'une seconde entre chaque mise à jour

                    if (Console.KeyAvailable)                                             // Si une touche est pressée
                    { 
                        var touche = Console.ReadKey(true).Key;                             // Lecture de la touche pressée
                        if (touche == ConsoleKey.S)                                        // Si la touche est S
                        {
                            enCours = false;                                                // On sort de la boucle du chrono
                        }
                    }
                }
            }
            else if (choix == "2")                  // Si l'utilisateur choisit d'arrêter
            {
                enCours = false;                    // On s'assure que le chrono s'arrête
            }
            else if (choix == "3")                  // Si l'utilisateur choisit de réinitialiser
            {
                elapsed = TimeSpan.Zero;            // On remet le compteur à zéro
            }
            else if (choix == "4")                  // Si l'utilisateur choisit de quitter
            {
                break;                              // On sort de la boucle principale
            }
        }

        Console.WriteLine("Chronomètre terminé. Appuyez sur une touche pour quitter.");
        Console.ReadKey();                                // On attend une touche pour fermer le programme
    }
}
