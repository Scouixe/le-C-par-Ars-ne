﻿using System;                            // Pour l'entrée et la sortie standard
using System.IO;                         // Pour lire et écrire dans des fichiers

class BlocNotes
{
    const string fichierNotes = "notes.txt";   // Le fichier où les notes seront sauvegardées

    static void Main()
    {
        while (true)
        {
            Console.Clear();                      // Nettoyage de la console
            Console.WriteLine("=== BLOC-NOTES SIMPLE ===");
            Console.WriteLine("[1] Lire les notes");
            Console.WriteLine("[2] Ajouter une note");
            Console.WriteLine("[3] Effacer toutes les notes");
            Console.WriteLine("[4] Quitter");
            Console.Write("\nVotre choix : ");
            string choix = Console.ReadLine();    // Lecture du choix utilisateur

            if (choix == "1")                     // Si l'utilisateur veut lire les notes
            {
                LireNotes();                      // Appel de la fonction LireNotes
            }
            else if (choix == "2")                // Si l'utilisateur veut ajouter une note
            {
                AjouterNote();                    // Appel de la fonction AjouterNote
            }
            else if (choix == "3")                // Si l'utilisateur veut effacer toutes les notes
            {
                EffacerNotes();                   // Appel de la fonction EffacerNotes
            }
            else if (choix == "4")                // Si l'utilisateur veut quitter
            {
                break;                            // On sort de la boucle principale
            }
            else
            {
                Console.WriteLine("Choix invalide.");  // Si la saisie est incorrecte
            }

            Console.WriteLine("\nAppuyez sur une touche pour continuer...");
            Console.ReadKey();                    // Attente d'une touche avant de continuer
        }
    }

    // Fonction pour lire les notes
    static void LireNotes()
    {
        Console.WriteLine("\n=== VOS NOTES ===");
        if (File.Exists(fichierNotes))                        // Vérifie si le fichier existe
        {
            string contenu = File.ReadAllText(fichierNotes); // Lit le contenu complet
            Console.WriteLine(contenu);                         // Affiche le contenu à l'écran
        }
        else
        {
            Console.WriteLine("Aucune note encore enregistrée."); // Message si fichier vide
        }
    }

    // Fonction pour ajouter une note
    static void AjouterNote()
    {
        Console.Write("\nÉcrivez votre note : ");
        string note = Console.ReadLine();                       // L'utilisateur écrit sa note
        string noteAvecDate = DateTime.Now + " : " + note;      // On ajoute la date et l'heure
        File.AppendAllText(fichierNotes, noteAvecDate + "\n");// On écrit la note dans le fichier
        Console.WriteLine("Note ajoutée avec succès !");        // Confirmation à l'utilisateur
    }

    // Fonction pour effacer toutes les notes
    static void EffacerNotes()
    {
        File.WriteAllText(fichierNotes, string.Empty);          // On écrase le fichier avec une chaîne vide
        Console.WriteLine("Toutes les notes ont été effacées."); // Confirmation à l'utilisateur
    }
}
